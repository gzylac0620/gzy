package anonymousClass;

public interface SourceInterface {

	public String getSource();
	
}
