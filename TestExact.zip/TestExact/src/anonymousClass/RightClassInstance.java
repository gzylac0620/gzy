package anonymousClass;

public class RightClassInstance implements SourceInterface{

	public String getSource()
	{
		return "";
	}
	
}
