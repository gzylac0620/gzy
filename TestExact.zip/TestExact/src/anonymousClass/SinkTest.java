package anonymousClass;

import java.io.IOException;

public class SinkTest {

	public void test(SourceInterface rightClassInstance) throws IOException
	{   
		String source = rightClassInstance.getSource();
		Runtime.getRuntime().exec(source);
	}
	
	//source点的类型实际是RightClassInstance,使用的是RightClassInstance中的方法getSouce
	public void test2(RightClassInstance rightClassInstance) throws IOException
	{   
		//source点的类型实际是RightClassInstance,使用的是RightClassInstance中的方法getSouce
		test(rightClassInstance);
	}
	
}
