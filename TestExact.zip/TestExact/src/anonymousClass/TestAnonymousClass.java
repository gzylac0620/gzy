package anonymousClass;

public class TestAnonymousClass {

	public SourceInterface getSourceInterface() {
		return new SourceInterface() {

			@Override
			public String getSource() {
				return System.getenv("test");
			}

		};
	}

}
