package lambda;

public class RightClassInstance implements SourceInterface{

	public String getSource()
	{
		return "";
	}
	
}
