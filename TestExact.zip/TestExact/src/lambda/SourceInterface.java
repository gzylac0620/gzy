package lambda;

public interface SourceInterface {

	public String getSource();
	
}
