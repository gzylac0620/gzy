package lambda;

public class TestAnonymousClass {

	public SourceInterface getSourceInterface() {
		return () -> System.getenv("test");
	}

}
