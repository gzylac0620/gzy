package classInstance;

import java.io.IOException;

public class SinkTest {

	public void test() throws IOException
	{   
		//source点的类型实际是RightClassInstance,使用的是RightClassInstance中的方法getSouce
		SourceInterface rightClassInstance = new RightClassInstance();
		String source = rightClassInstance.getSource();
		Runtime.getRuntime().exec(source);
	}
	
}
