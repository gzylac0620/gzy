package classInstance;

public interface SourceInterface {

	public String getSource();
	
}
