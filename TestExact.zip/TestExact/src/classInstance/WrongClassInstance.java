package classInstance;

public class WrongClassInstance extends RightClassInstance{
    
	@Override
	public String getSource()
	{
		return System.getenv("test");
	}
	
}
